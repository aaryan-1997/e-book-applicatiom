const String appName = "eBook";

const String iosAppId = "585027354";
const String packageName = "com.my.ebook";
// for add_mob InterstitialAdUnitID
const String interstitialAdUnitIDAndroid =
    "ca-app-pub-3940256099942544/1033173712";
const String interstitialAdUnitIDIos =
    "cca-app-pub-3940256099942544/1033173712";

// for add_mob bannerAdUnitId
const String bannerAdUnitIdAdnroid = "ca-app-pub-3940256099942544/1033173712";
const String bannerAdUnitIdIos = "ca-app-pub-3940256099942544/2934735716";

// facebook adds ID

const String facebockID = "a77955ee-3304-4635-be65-81029b0f5201";
